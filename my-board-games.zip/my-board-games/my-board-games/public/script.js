const API_URL = "http://localhost:3000/games";

async function loadGames() {
    const response = await fetch(API_URL);
    const games = await response.json();
    const list = document.getElementById("game-list");
    list.innerHTML = games.map(game => `
        <tr>
            <td>${game.id}</td>
            <td>${game.name}</td>
            <td>${game.minPlayers}–${game.maxPlayers}</td>
            <td>${game.playTime}</td>
            <td>
                <a class="btn blue" href="form.html?id=${game.id}">Редагувати</a>
                <button class="btn red" onclick="deleteGame(${game.id})">Видалити</button>
            </td>
        </tr>
    `).join('');
}

async function deleteGame(id) {
    await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    loadGames();
}

async function loadForm() {
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");
    if (id) {
        document.getElementById("form-title").textContent = "Редагувати гру";
        const res = await fetch(`${API_URL}/${id}`);
        const game = await res.json();
        document.getElementById("game-id").value = game.id;
        document.getElementById("name").value = game.name;
        document.getElementById("minPlayers").value = game.minPlayers;
        document.getElementById("maxPlayers").value = game.maxPlayers;
        document.getElementById("playTime").value = game.playTime;
        M.updateTextFields();
    }
}

document.getElementById("game-form")?.addEventListener("submit", async function (e) {
    e.preventDefault();
    const id = document.getElementById("game-id").value;
    const data = {
        name: document.getElementById("name").value,
        minPlayers: +document.getElementById("minPlayers").value,
        maxPlayers: +document.getElementById("maxPlayers").value,
        playTime: +document.getElementById("playTime").value
    };

    const options = {
        method: id ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    };

    await fetch(id ? `${API_URL}/${id}` : API_URL, options);
    window.location.href = "index.html";
});

if (document.getElementById("game-list")) loadGames();
if (document.getElementById("game-form")) loadForm();