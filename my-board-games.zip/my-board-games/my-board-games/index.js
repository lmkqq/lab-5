const express = require("express");
const app = express();
const PORT = 3000;

app.use(express.static("public"));
app.use(express.json());

let games = [
    { id: 1, name: "Каркассон", minPlayers: 2, maxPlayers: 5, playTime: 45 },
    { id: 2, name: "Колонізатори", minPlayers: 3, maxPlayers: 4, playTime: 90 }
];

app.get("/games", (req, res) => res.json(games));

app.get("/games/:id", (req, res) => {
    const game = games.find(g => g.id == req.params.id);
    if (!game) return res.status(404).json({ message: "Гру не знайдено" });
    res.json(game);
});

app.post("/games", (req, res) => {
    const { name, minPlayers, maxPlayers, playTime } = req.body;
    const id = games.length ? games[games.length - 1].id + 1 : 1;
    const newGame = { id, name, minPlayers, maxPlayers, playTime };
    games.push(newGame);
    res.status(201).json(newGame);
});

app.put("/games/:id", (req, res) => {
    const game = games.find(g => g.id == req.params.id);
    if (!game) return res.status(404).json({ message: "Гру не знайдено" });

    const { name, minPlayers, maxPlayers, playTime } = req.body;
    Object.assign(game, { name, minPlayers, maxPlayers, playTime });
    res.json(game);
});

app.delete("/games/:id", (req, res) => {
    const index = games.findIndex(g => g.id == req.params.id);
    if (index === -1) return res.status(404).json({ message: "Гру не знайдено" });

    games.splice(index, 1);
    res.json({ message: "Гру видалено" });
});

app.listen(PORT, () => console.log(`Сервер працює на http://localhost:${PORT}`));